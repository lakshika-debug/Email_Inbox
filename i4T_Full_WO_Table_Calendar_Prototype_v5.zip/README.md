# i4T Maintenance – Future & Recurring WO Table + Calendar Prototype V5

Open `future-recurring.html` in a browser. The sidebar switches between the separate Future & Recurring table and Calendar pages.

## What's included

**Future & Recurring table**: Existing Recurring WO ID and Task ID; view/edit; pause/resume for recurring only; cancel with confirmation; cancelled records become view-only. Edit changes only future unissued occurrences. Quarterly is included.

**Calendar**: Regular Work Orders start as blue Created blocks on their creation timestamp. Supplier appointment confirmations move the same event to the appointment date/time and make it orange Scheduled. Future and recurring projected occurrences are orange at their requested date/time. All blocks represent two hours for visualisation, not job duration. Event popovers include read-only navigation and display a linked actual WO number once generated. The calendar retains Day, Week, Month and Timeline views and Created/Scheduled filters only.

**i4T Business integration demo controls** (visibly labelled *Prototype scenarios*, not real product actions): schedule a regular WO, reschedule it, generate one recurring WO at midnight, schedule the generated WO individually, simulate a compliance-blocked occurrence with next-day emails, simulate the seven-day reminder, and reset. The on-screen Integration activity panel shows the simulated events.

## Scope and safety

This is a **frontend-only prototype with fabricated sample data**. The demonstrations never send emails, validate real compliance records, issue WOs or communicate with i4T Business. Data is held in browser memory and resets on refresh. The original AI Inbox app/repository is not modified. Real i4T Business event synchronisation, user authorisation, notification delivery, idempotent midnight jobs, and property-local timezone execution require backend implementation.

## User stories

The prototype visibly covers WO table actions, schedule identifiers, Created/Scheduled calendar states, fixed-duration display, rescheduling, generated-WO linkage, recurring pattern preservation, and compliance/notification scenario examples. The existing full WO creation flow and supplier-side employee scheduling UI have intentionally **not** been recreated; those remain separate i4T application workflows.
